Thank you for downloading The Night of The Puppets: Terrain Texture Pack

---TERM OF USE---
This texture pack contains 7 256x256 textures in jpg format that were originally created for a prototype game named "The night of The Puppets".
Those textures are free for use in non commercial projects.
This ZIP file il freely redistributable as long as it remains FREE and keeps this readme file unalterated.
You can modifiy the textures and redistribute them, but even in this case THEY HAVE TO REMAIN FREE.

Do not hesitate to send us feedback!
And do not forget to tell us if you use or redistribute them, we will put a link on our site pointing to your project as a sign of mutual friendship. :P

A link to our website or a donation is always appreciated, too.

For commercial projects, please send an email.

---AUTHOR INFO---
Author:	 Marco "DITz" Di Timoteo - STUDIO EVIL
Email:	 team@studioevil.com
Website: http://www.studioevil.com

---TEXTURE PACK INFO---
Title: The Night of The Puppets: Terrain Texture Pack
Version: 1.0
Release date: 10/10/07 (DD/MM/YY)

---COPYRIGHT/INFO---
.zip file copyright (c) 2007 STUDIO EVIL
All rights reserved.

THIS ZIP FILE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. THE AUTHOR FURTHER DISCLAIMS ALL
IMPLIED WARRANTIES INCLUDING WITHOUT LIMITATION ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR OF
FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK ARISING OUT OF THE USE OR PERFORMANCE OF THE
SOFTWARE AND DOCUMENTATION REMAINS WITH YOU.

IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION,
DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR
OTHER PECUNIARY LOSS) ARISING OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE OR DOCUMENTATION
EVEN IF THE AUTHOR HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

This texture pack may be electronically distributed only at NO CHARGE to the recipient in its
current state, MUST include this .txt file, and may NOT be modified IN ANY WAY. UNDER NO
CIRCUMSTANCES IS THIS FILES TO BE DISTRIBUTED ON CD-ROM WITHOUT PRIOR WRITTEN PERMISSION.